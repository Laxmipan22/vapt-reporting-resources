## VAPT Methodology

1. Reconnaissance
2. Scanning & Enumeration
3. Vulnerability Analysis
4. Exploitation
5. Post-Exploitation
6. Reporting
