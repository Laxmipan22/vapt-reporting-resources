## VAPT Cheat Sheet

### Recon Tools:
- `nmap -sV -T4 -A 192.168.1.1`
- `dirsearch`, `gobuster`

### Exploitation:
- `sqlmap`, `hydra`, `burpsuite`

### Privilege Escalation:
- `linpeas.sh`, `winPEAS.exe`
