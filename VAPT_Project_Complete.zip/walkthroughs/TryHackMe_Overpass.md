# TryHackMe - Overpass Walkthrough

**Target:** 10.10.10.10

### Steps:
1. Nmap Scan
2. Directory Enumeration
3. Exploiting vulnerable login
4. Privilege escalation

**Proof:** `root.txt` obtained.