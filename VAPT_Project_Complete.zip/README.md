# VAPT Project (Non-Coding)

This repository includes various resources and reports related to Vulnerability Assessment and Penetration Testing (VAPT).

## Structure
- `/templates/`: Report templates
- `/reports/`: Sample reports
- `/walkthroughs/`: THM/HTB writeups
- `/methodology/`: Testing process
- `/cheatsheets/`: Common commands & tools
